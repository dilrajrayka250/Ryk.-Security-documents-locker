package com.securedocs.app.utils

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object Prefs {

    private const val PREF_NAME = "ryk_secure_prefs"
    private const val KEY_PIN = "user_pin"
    private const val KEY_PREMIUM = "is_premium"
    private const val KEY_PIN_SET = "pin_set"
    private const val KEY_PURCHASE_TOKEN = "purchase_token"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()

            prefs = EncryptedSharedPreferences.create(
                context,
                PREF_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            // Fallback to regular SharedPreferences
            prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        }
    }

    fun savePin(pin: String) {
        prefs.edit()
            .putString(KEY_PIN, pin)
            .putBoolean(KEY_PIN_SET, true)
            .apply()
    }

    fun getPin(): String = prefs.getString(KEY_PIN, "") ?: ""

    fun isPinSet(): Boolean = prefs.getBoolean(KEY_PIN_SET, false)

    fun verifyPin(inputPin: String): Boolean = getPin() == inputPin

    fun setPremium(isPremium: Boolean, purchaseToken: String = "") {
        prefs.edit()
            .putBoolean(KEY_PREMIUM, isPremium)
            .putString(KEY_PURCHASE_TOKEN, purchaseToken)
            .apply()
    }

    fun isPremium(): Boolean = prefs.getBoolean(KEY_PREMIUM, false)

    fun getPurchaseToken(): String = prefs.getString(KEY_PURCHASE_TOKEN, "") ?: ""

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
