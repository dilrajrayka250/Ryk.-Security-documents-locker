package com.securedocs.app.ui

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdView
import com.securedocs.app.R
import com.securedocs.app.ads.AdManager
import com.securedocs.app.storage.FileManager
import com.securedocs.app.utils.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BackupActivity : AppCompatActivity() {

    private lateinit var adView: AdView
    private lateinit var btnBackup: Button
    private lateinit var btnWatchAd: Button
    private lateinit var tvBackupStatus: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup)

        adView = findViewById(R.id.adViewBackup)
        btnBackup = findViewById(R.id.btnStartBackup)
        btnWatchAd = findViewById(R.id.btnWatchAdBackup)
        tvBackupStatus = findViewById(R.id.tvBackupStatus)
        progressBar = findViewById(R.id.progressBackup)

        AdManager.loadBanner(this, adView)
        AdManager.loadRewarded(this)

        updateUI()

        btnBackup.setOnClickListener {
            if (Prefs.isPremium()) {
                startBackup()
            } else {
                showPremiumNeeded()
            }
        }

        btnWatchAd.setOnClickListener {
            AdManager.showRewarded(
                activity = this,
                onRewarded = {
                    Toast.makeText(this, "Ad देखने के लिए धन्यवाद! 1 Backup मिला।", Toast.LENGTH_SHORT).show()
                    startBackup()
                },
                onDismiss = {
                    Toast.makeText(this, "Ad dismiss हो गई", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    private fun updateUI() {
        val isPremium = Prefs.isPremium()
        btnBackup.text = if (isPremium) "Backup Now (Premium)" else "Backup (Premium Only)"
        btnWatchAd.visibility = if (isPremium) View.GONE else View.VISIBLE
    }

    private fun startBackup() {
        progressBar.visibility = View.VISIBLE
        tvBackupStatus.text = "Backup चल रहा है..."
        btnBackup.isEnabled = false

        CoroutineScope(Dispatchers.IO).launch {
            val count = FileManager.backupFiles(this@BackupActivity)
            withContext(Dispatchers.Main) {
                progressBar.visibility = View.GONE
                tvBackupStatus.text = "Backup Complete! $count files backup हो गई।"
                btnBackup.isEnabled = true
                Toast.makeText(this@BackupActivity, "Backup successful!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showPremiumNeeded() {
        Toast.makeText(this, "Backup के लिए Premium चाहिए या Ad देखें!", Toast.LENGTH_LONG).show()
    }
}
