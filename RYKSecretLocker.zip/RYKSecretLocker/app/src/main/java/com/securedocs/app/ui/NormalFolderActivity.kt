package com.securedocs.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.ads.AdView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.securedocs.app.R
import com.securedocs.app.ads.AdManager
import com.securedocs.app.storage.FileManager
import java.io.File

class NormalFolderActivity : AppCompatActivity() {

    private lateinit var rvFiles: RecyclerView
    private lateinit var adView: AdView
    private lateinit var fab: FloatingActionButton
    private lateinit var tvEmpty: TextView
    private val fileList = mutableListOf<File>()

    companion object {
        private const val PICK_FILE_REQUEST = 101
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_normal_folder)

        rvFiles = findViewById(R.id.rvNormalFiles)
        adView = findViewById(R.id.adViewNormal)
        fab = findViewById(R.id.fabAddFile)
        tvEmpty = findViewById(R.id.tvEmptyNormal)

        AdManager.loadBanner(this, adView)
        setupRecyclerView()
        loadFiles()

        fab.setOnClickListener { openFilePicker() }
    }

    private fun setupRecyclerView() {
        rvFiles.layoutManager = LinearLayoutManager(this)
        rvFiles.adapter = FileAdapter(fileList) { file ->
            FileManager.deleteFile(file)
            Toast.makeText(this, "File delete हो गई", Toast.LENGTH_SHORT).show()
            loadFiles()
        }
    }

    private fun loadFiles() {
        fileList.clear()
        fileList.addAll(FileManager.listNormalFiles(this))
        rvFiles.adapter?.notifyDataSetChanged()
        tvEmpty.visibility = if (fileList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, PICK_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "file_${System.currentTimeMillis()}"
            val success = FileManager.saveNormalFile(this, uri, fileName)
            if (success) {
                Toast.makeText(this, "File save हो गई!", Toast.LENGTH_SHORT).show()
                loadFiles()
            } else {
                Toast.makeText(this, "File save नहीं हो सकी", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ─── File Adapter ──────────────────────────────────────────────────────────
    class FileAdapter(
        private val files: List<File>,
        private val onDelete: (File) -> Unit
    ) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

        inner class FileViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val tvName: TextView = view.findViewById(R.id.tvFileName)
            val tvSize: TextView = view.findViewById(R.id.tvFileSize)
            val tvDelete: TextView = view.findViewById(R.id.tvDeleteFile)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_file, parent, false)
            return FileViewHolder(view)
        }

        override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
            val file = files[position]
            holder.tvName.text = file.name
            holder.tvSize.text = FileManager.getReadableFileSize(file.length())
            holder.tvDelete.setOnClickListener { onDelete(file) }
        }

        override fun getItemCount() = files.size
    }
}
