package com.securedocs.app.ads

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.securedocs.app.utils.Prefs

object AdManager {

    // ── Test Ad Unit IDs (Replace with real ones before publishing) ────────────
    const val BANNER_AD_UNIT_ID     = "ca-app-pub-3940256099942544/6300978111"
    const val INTERSTITIAL_AD_UNIT  = "ca-app-pub-3940256099942544/1033173712"
    const val REWARDED_AD_UNIT      = "ca-app-pub-3940256099942544/5224354917"

    private var mInterstitialAd: InterstitialAd? = null
    private var mRewardedAd: RewardedAd? = null

    // ─── Initialize AdMob ──────────────────────────────────────────────────────
    fun initialize(context: Context) {
        MobileAds.initialize(context) {}
    }

    // ─── Banner Ad ─────────────────────────────────────────────────────────────
    fun loadBanner(activity: Activity, adView: AdView) {
        if (Prefs.isPremium()) {
            adView.visibility = android.view.View.GONE
            return
        }
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        adView.visibility = android.view.View.VISIBLE
    }

    // ─── Interstitial Ad ───────────────────────────────────────────────────────
    fun loadInterstitial(context: Context) {
        if (Prefs.isPremium()) return
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            INTERSTITIAL_AD_UNIT,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    mInterstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    mInterstitialAd = null
                }
            }
        )
    }

    fun showInterstitial(activity: Activity, onDismiss: () -> Unit) {
        if (Prefs.isPremium()) {
            onDismiss()
            return
        }
        if (mInterstitialAd != null) {
            mInterstitialAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    mInterstitialAd = null
                    loadInterstitial(activity)
                    onDismiss()
                }
            }
            mInterstitialAd?.show(activity)
        } else {
            onDismiss()
        }
    }

    // ─── Rewarded Ad ───────────────────────────────────────────────────────────
    fun loadRewarded(context: Context) {
        if (Prefs.isPremium()) return
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            REWARDED_AD_UNIT,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    mRewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    mRewardedAd = null
                }
            }
        )
    }

    fun showRewarded(activity: Activity, onRewarded: () -> Unit, onDismiss: () -> Unit) {
        if (mRewardedAd != null) {
            mRewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    mRewardedAd = null
                    loadRewarded(activity)
                    onDismiss()
                }
            }
            mRewardedAd?.show(activity) {
                onRewarded()
            }
        } else {
            onDismiss()
        }
    }
}
