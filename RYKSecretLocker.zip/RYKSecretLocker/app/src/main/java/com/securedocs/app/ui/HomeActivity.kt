package com.securedocs.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdView
import com.securedocs.app.R
import com.securedocs.app.ads.AdManager
import com.securedocs.app.billing.BillingManager
import com.securedocs.app.utils.Prefs

class HomeActivity : AppCompatActivity() {

    private lateinit var billingManager: BillingManager
    private lateinit var adView: AdView
    private lateinit var tvPremiumBadge: TextView
    private lateinit var cardNormal: LinearLayout
    private lateinit var cardPrivate: LinearLayout
    private lateinit var cardScanner: LinearLayout
    private lateinit var cardBackup: LinearLayout
    private lateinit var btnUpgrade: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        initViews()
        setupBilling()
        loadAds()
        updatePremiumUI()
        setupClickListeners()
    }

    private fun initViews() {
        adView = findViewById(R.id.adViewHome)
        tvPremiumBadge = findViewById(R.id.tvPremiumBadge)
        cardNormal = findViewById(R.id.cardNormal)
        cardPrivate = findViewById(R.id.cardPrivate)
        cardScanner = findViewById(R.id.cardScanner)
        cardBackup = findViewById(R.id.cardBackup)
        btnUpgrade = findViewById(R.id.btnUpgradePremium)
    }

    private fun setupBilling() {
        billingManager = BillingManager(this) {
            updatePremiumUI()
        }
        billingManager.init()
    }

    private fun loadAds() {
        AdManager.loadBanner(this, adView)
        AdManager.loadInterstitial(this)
    }

    private fun updatePremiumUI() {
        val isPremium = Prefs.isPremium()
        tvPremiumBadge.visibility = if (isPremium) View.VISIBLE else View.GONE
        btnUpgrade.visibility = if (isPremium) View.GONE else View.VISIBLE
        adView.visibility = if (isPremium) View.GONE else View.VISIBLE
    }

    private fun setupClickListeners() {
        cardNormal.setOnClickListener {
            startActivity(Intent(this, NormalFolderActivity::class.java))
        }

        cardPrivate.setOnClickListener {
            if (Prefs.isPremium()) {
                startActivity(Intent(this, PrivateFolderActivity::class.java))
            } else {
                showUpgradeDialog()
            }
        }

        cardScanner.setOnClickListener {
            AdManager.showInterstitial(this) {
                startActivity(Intent(this, ScannerActivity::class.java))
            }
        }

        cardBackup.setOnClickListener {
            startActivity(Intent(this, BackupActivity::class.java))
        }

        btnUpgrade.setOnClickListener {
            showUpgradeDialog()
        }
    }

    private fun showUpgradeDialog() {
        AlertDialog.Builder(this, R.style.PremiumDialog)
            .setTitle("Premium Unlock करें")
            .setMessage("सिर्फ ${BillingManager.PREMIUM_PRICE} में:\n\n✅ Private Encrypted Folder\n✅ कोई Ads नहीं\n✅ Unlimited Backup\n✅ QR Scanner Ad-Free")
            .setPositiveButton("${BillingManager.PREMIUM_PRICE} में Unlock") { _, _ ->
                billingManager.launchPurchase()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        billingManager.destroy()
    }
}
