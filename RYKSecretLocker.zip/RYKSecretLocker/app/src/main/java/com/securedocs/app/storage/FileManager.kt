package com.securedocs.app.storage

import android.content.Context
import android.net.Uri
import com.securedocs.app.security.EncryptionHelper
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream

object FileManager {

    private const val NORMAL_DIR = "normal_docs"
    private const val PRIVATE_DIR = "private_docs"
    private const val BACKUP_DIR = "backup"

    // ─── Folder Paths ──────────────────────────────────────────────────────────
    fun getNormalFolder(context: Context): File {
        val dir = File(context.filesDir, NORMAL_DIR)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getPrivateFolder(context: Context): File {
        val dir = File(context.filesDir, PRIVATE_DIR)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getBackupFolder(context: Context): File {
        val dir = File(context.filesDir, BACKUP_DIR)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // ─── Save Normal File ──────────────────────────────────────────────────────
    fun saveNormalFile(context: Context, uri: Uri, fileName: String): Boolean {
        return try {
            val inputStream: InputStream = context.contentResolver.openInputStream(uri) ?: return false
            val outputFile = File(getNormalFolder(context), fileName)
            val outputStream = FileOutputStream(outputFile)
            inputStream.copyTo(outputStream)
            inputStream.close()
            outputStream.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // ─── Save Encrypted (Private) File ─────────────────────────────────────────
    fun savePrivateFile(context: Context, uri: Uri, fileName: String): Boolean {
        return try {
            val inputStream: InputStream = context.contentResolver.openInputStream(uri) ?: return false
            val rawBytes = inputStream.readBytes()
            inputStream.close()
            val encryptedBytes = EncryptionHelper.encrypt(rawBytes)
            val outputFile = File(getPrivateFolder(context), "$fileName.enc")
            val fos = FileOutputStream(outputFile)
            fos.write(encryptedBytes)
            fos.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    // ─── Read Decrypted Private File ───────────────────────────────────────────
    fun readPrivateFile(file: File): ByteArray? {
        return try {
            val encryptedBytes = file.readBytes()
            EncryptionHelper.decrypt(encryptedBytes)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // ─── List Normal Files ─────────────────────────────────────────────────────
    fun listNormalFiles(context: Context): List<File> {
        return getNormalFolder(context).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    // ─── List Private Files ────────────────────────────────────────────────────
    fun listPrivateFiles(context: Context): List<File> {
        return getPrivateFolder(context).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
    }

    // ─── Delete File ───────────────────────────────────────────────────────────
    fun deleteFile(file: File): Boolean = file.delete()

    // ─── Backup All Files ──────────────────────────────────────────────────────
    fun backupFiles(context: Context): Int {
        var count = 0
        val backupDir = getBackupFolder(context)
        listNormalFiles(context).forEach { file ->
            val dest = File(backupDir, "normal_${file.name}")
            if (file.copyTo(dest, overwrite = true).exists()) count++
        }
        listPrivateFiles(context).forEach { file ->
            val dest = File(backupDir, "private_${file.name}")
            if (file.copyTo(dest, overwrite = true).exists()) count++
        }
        return count
    }

    // ─── Get Readable File Size ────────────────────────────────────────────────
    fun getReadableFileSize(sizeBytes: Long): String {
        return when {
            sizeBytes < 1024 -> "$sizeBytes B"
            sizeBytes < 1024 * 1024 -> "${sizeBytes / 1024} KB"
            sizeBytes < 1024 * 1024 * 1024 -> "${sizeBytes / (1024 * 1024)} MB"
            else -> "${sizeBytes / (1024 * 1024 * 1024)} GB"
        }
    }

    // ─── Get File Extension ────────────────────────────────────────────────────
    fun getFileExtension(fileName: String): String {
        return fileName.substringAfterLast(".", "")
    }
}
