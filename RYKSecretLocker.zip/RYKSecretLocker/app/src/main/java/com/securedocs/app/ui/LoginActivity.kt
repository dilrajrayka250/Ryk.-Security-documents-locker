package com.securedocs.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.securedocs.app.R
import com.securedocs.app.utils.Prefs

class LoginActivity : AppCompatActivity() {

    private val enteredPin = StringBuilder()
    private lateinit var tvPinDisplay: TextView
    private lateinit var tvTitle: TextView
    private var isSettingPin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        tvPinDisplay = findViewById(R.id.tvPinDisplay)
        tvTitle = findViewById(R.id.tvLoginTitle)

        isSettingPin = !Prefs.isPinSet()
        tvTitle.text = if (isSettingPin) "नया PIN सेट करें" else "PIN डालें"

        setupNumpad()
    }

    private fun setupNumpad() {
        val btnIds = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
            R.id.btn4, R.id.btn5, R.id.btn6, R.id.btn7,
            R.id.btn8, R.id.btn9
        )
        btnIds.forEachIndexed { index, id ->
            val num = if (id == R.id.btn0) "0" else index.toString()
            findViewById<Button>(id).setOnClickListener { onDigitPressed(num) }
        }
        findViewById<Button>(R.id.btnBackspace).setOnClickListener { onBackspace() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearPin() }
    }

    private fun onDigitPressed(digit: String) {
        if (enteredPin.length >= 6) return
        enteredPin.append(digit)
        updatePinDisplay()
        if (enteredPin.length == 4) {
            processPin()
        }
    }

    private fun onBackspace() {
        if (enteredPin.isNotEmpty()) {
            enteredPin.deleteCharAt(enteredPin.length - 1)
            updatePinDisplay()
        }
    }

    private fun clearPin() {
        enteredPin.clear()
        updatePinDisplay()
    }

    private fun updatePinDisplay() {
        val dots = "● ".repeat(enteredPin.length) + "○ ".repeat(4 - enteredPin.length)
        tvPinDisplay.text = dots.trim()
    }

    private fun processPin() {
        val pin = enteredPin.toString()
        if (isSettingPin) {
            Prefs.savePin(pin)
            Toast.makeText(this, "PIN सेट हो गया!", Toast.LENGTH_SHORT).show()
            goToHome()
        } else {
            if (Prefs.verifyPin(pin)) {
                goToHome()
            } else {
                Toast.makeText(this, "गलत PIN! फिर से try करें", Toast.LENGTH_SHORT).show()
                clearPin()
                tvPinDisplay.setTextColor(getColor(R.color.error_red))
                tvPinDisplay.postDelayed({
                    tvPinDisplay.setTextColor(getColor(R.color.white))
                }, 600)
            }
        }
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
