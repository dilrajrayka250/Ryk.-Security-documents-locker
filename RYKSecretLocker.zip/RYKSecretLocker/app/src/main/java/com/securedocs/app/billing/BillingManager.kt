package com.securedocs.app.billing

import android.app.Activity
import android.content.Context
import android.widget.Toast
import com.android.billingclient.api.*
import com.securedocs.app.utils.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class BillingManager(
    private val activity: Activity,
    private val onPremiumUnlocked: () -> Unit
) : PurchasesUpdatedListener {

    companion object {
        const val PREMIUM_PRODUCT_ID = "ryk_premium_unlock"   // Play Console में यही ID डालें
        const val PREMIUM_PRICE = "₹9"
    }

    private lateinit var billingClient: BillingClient
    private val scope = CoroutineScope(Dispatchers.Main)

    fun init() {
        billingClient = BillingClient.newBuilder(activity)
            .setListener(this)
            .enablePendingPurchases()
            .build()

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    checkExistingPurchases()
                }
            }

            override fun onBillingServiceDisconnected() {
                // Retry logic here if needed
            }
        })
    }

    // ─── Check if user already bought premium ──────────────────────────────────
    private fun checkExistingPurchases() {
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                billingClient.queryPurchasesAsync(
                    QueryPurchasesParams.newBuilder()
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
                )
            }
            result.purchasesList.forEach { purchase ->
                if (purchase.products.contains(PREMIUM_PRODUCT_ID) &&
                    purchase.purchaseState == Purchase.PurchaseState.PURCHASED
                ) {
                    Prefs.setPremium(true, purchase.purchaseToken)
                    onPremiumUnlocked()
                }
            }
        }
    }

    // ─── Launch Purchase Flow ──────────────────────────────────────────────────
    fun launchPurchase() {
        scope.launch {
            val productList = listOf(
                QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(PREMIUM_PRODUCT_ID)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build()
            )
            val params = QueryProductDetailsParams.newBuilder()
                .setProductList(productList)
                .build()

            val result = withContext(Dispatchers.IO) {
                billingClient.queryProductDetails(params)
            }

            val productDetails = result.productDetailsList?.firstOrNull()
            if (productDetails != null) {
                val flowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(
                        listOf(
                            BillingFlowParams.ProductDetailsParams.newBuilder()
                                .setProductDetails(productDetails)
                                .build()
                        )
                    )
                    .build()
                billingClient.launchBillingFlow(activity, flowParams)
            } else {
                Toast.makeText(activity, "Product नहीं मिला। Internet check करें।", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ─── Purchase Result ───────────────────────────────────────────────────────
    override fun onPurchasesUpdated(billingResult: BillingResult, purchases: List<Purchase>?) {
        when (billingResult.responseCode) {
            BillingClient.BillingResponseCode.OK -> {
                purchases?.forEach { purchase ->
                    if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                        acknowledgePurchase(purchase)
                        Prefs.setPremium(true, purchase.purchaseToken)
                        onPremiumUnlocked()
                    }
                }
            }
            BillingClient.BillingResponseCode.USER_CANCELED -> {
                Toast.makeText(activity, "Purchase cancel किया गया", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(activity, "Purchase error: ${billingResult.debugMessage}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun acknowledgePurchase(purchase: Purchase) {
        if (!purchase.isAcknowledged) {
            val params = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.purchaseToken)
                .build()
            billingClient.acknowledgePurchase(params) {}
        }
    }

    fun destroy() {
        if (::billingClient.isInitialized) billingClient.endConnection()
    }
}
