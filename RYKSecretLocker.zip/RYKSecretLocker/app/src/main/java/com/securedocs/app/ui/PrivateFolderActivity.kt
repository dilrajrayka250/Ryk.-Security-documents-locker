package com.securedocs.app.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.securedocs.app.R
import com.securedocs.app.storage.FileManager
import java.io.File

class PrivateFolderActivity : AppCompatActivity() {

    private lateinit var rvPrivateFiles: RecyclerView
    private lateinit var fab: FloatingActionButton
    private lateinit var tvEmpty: TextView
    private val fileList = mutableListOf<File>()
    private var isAuthenticated = false

    companion object {
        private const val PICK_FILE_REQUEST = 202
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_private_folder)

        rvPrivateFiles = findViewById(R.id.rvPrivateFiles)
        fab = findViewById(R.id.fabAddPrivate)
        tvEmpty = findViewById(R.id.tvEmptyPrivate)

        setupRecyclerView()
        authenticateUser()

        fab.setOnClickListener {
            if (isAuthenticated) openFilePicker()
            else Toast.makeText(this, "पहले Authenticate करें", Toast.LENGTH_SHORT).show()
        }
    }

    private fun authenticateUser() {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        if (canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            showBiometricPrompt()
        } else {
            // Biometric नहीं है तो directly open करो (PIN already verify हो चुका)
            isAuthenticated = true
            loadFiles()
        }
    }

    private fun showBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                isAuthenticated = true
                loadFiles()
                Toast.makeText(this@PrivateFolderActivity, "Private Folder Unlocked!", Toast.LENGTH_SHORT).show()
            }

            override fun onAuthenticationFailed() {
                Toast.makeText(this@PrivateFolderActivity, "Authentication failed", Toast.LENGTH_SHORT).show()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                finish()
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Private Documents")
            .setSubtitle("RYK Secret Locker")
            .setDescription("AES-256 Encrypted Folder")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }

    private fun setupRecyclerView() {
        rvPrivateFiles.layoutManager = LinearLayoutManager(this)
        rvPrivateFiles.adapter = PrivateFileAdapter(fileList) { file ->
            FileManager.deleteFile(file)
            Toast.makeText(this, "Encrypted file delete हो गई", Toast.LENGTH_SHORT).show()
            loadFiles()
        }
    }

    private fun loadFiles() {
        fileList.clear()
        fileList.addAll(FileManager.listPrivateFiles(this))
        rvPrivateFiles.adapter?.notifyDataSetChanged()
        tvEmpty.visibility = if (fileList.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, PICK_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            val uri: Uri = data?.data ?: return
            val fileName = uri.lastPathSegment?.substringAfterLast("/") ?: "file_${System.currentTimeMillis()}"
            val success = FileManager.savePrivateFile(this, uri, fileName)
            if (success) {
                Toast.makeText(this, "File AES Encrypt होकर save हो गई!", Toast.LENGTH_SHORT).show()
                loadFiles()
            } else {
                Toast.makeText(this, "Encryption error", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class PrivateFileAdapter(
        private val files: List<File>,
        private val onDelete: (File) -> Unit
    ) : RecyclerView.Adapter<PrivateFileAdapter.VH>() {

        inner class VH(view: View) : RecyclerView.ViewHolder(view) {
            val tvName: TextView = view.findViewById(R.id.tvFileName)
            val tvSize: TextView = view.findViewById(R.id.tvFileSize)
            val tvDelete: TextView = view.findViewById(R.id.tvDeleteFile)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val file = files[position]
            holder.tvName.text = "🔒 ${file.name.removeSuffix(".enc")}"
            holder.tvSize.text = FileManager.getReadableFileSize(file.length())
            holder.tvDelete.setOnClickListener { onDelete(file) }
        }

        override fun getItemCount() = files.size
    }
}
